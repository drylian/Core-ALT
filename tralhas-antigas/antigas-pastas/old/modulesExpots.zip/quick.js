const { QuickDB } = require("quick.db");
const config = require('../../src/config')
const db = new QuickDB({ filePath: config.sysPath + "/data.sqlite" });
module.exports = { db }