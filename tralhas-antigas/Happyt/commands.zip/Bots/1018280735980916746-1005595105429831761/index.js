const { Client } = require("discord.js")

const client = new Client({ intents: 32767 })

client.on("ready", async() => {
   client.channels.cache.get('1049163001296588893').send('Oiiii')
});

client.login('MTAxODI4MDczNTk4MDkxNjc0Ng.GfGWwT.0swoa-51liREGqShYXl6k_3Y8Kdc5uViZX6sb4');