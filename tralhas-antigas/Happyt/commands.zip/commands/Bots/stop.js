const pm2 = require('pm2')
const Discord = require('discord.js');
const fs = require('fs');
let random = 'RANDOM'
let quickdb = require('quick.db')


module.exports = {
	name: "stop",
	category: "Bots",
	usage: 'stop [id do bot]',
	aliases: ['parar', 's'],
	description: "Veja meus comandos.",
	run: async (client, message, args) => {
		let id = args[0]
		if (!id) return message.reply('you need to send me the id from your bot!')
		if (fs.existsSync(`Bots/${id}-${message.author.id}`)) {
			pm2.stop(id)
			message.reply('bot stoped sucesfully!')
			let channel = message.guild.channels.cache.get('1049875345576296579')
			let embed2 = new Discord.MessageEmbed()
				.setColor(random)
				.setDescription(`bot stoped sucesfully! \n bot: <@${id}>`)
			channel.send(message.author, embed2)
			quickdb.set(`${id}`, false)
      quickdb.set("BotsOnline",quickdb.get("BotsOnline") - 1 )
		} else return message.reply('please give me a valid bot id!')
	}
}