let pm2 = require('pm2')
const Discord = require('discord.js')
var https = require('https');
var fs = require('fs');
let URL = require('url')
let ZipCode = 00000
let random = 'RANDOM'
let quickdb = require('quick.db')
// fs.mkdirSync('./bots/pasta')

var download = async function(url, idbot) {
  if (fs.existsSync('botszip/' + `ot-${idbot}.zip`)) {
    ZipCode = Math.random() * (99999 - 00000) + 00000
		download(url, idbot)
  }else{
  	const file = fs.createWriteStream(`botszip/bot-${idbot}.zip`);
  	https.get(url, res => {
  		res.pipe(file)
  	});
  }
}

let unzip = async function(name) {
	setTimeout(function() {
		const decompress = require("decompress");
		//Ping
		decompress("botszip/bot.zip", "Bots/" + name).then((files, err) => {
			console.log(files);
			if (err) console.error(err)
		});
		setTimeout(function() {
			fs.unlinkSync("botszip/bot.zip")
		}, 3000);
	}, 3000);
}
let ramfree = "100M"
let rambasic = "300M"
let rammedium = "500M"
let ramexpert = "1500M"

module.exports = {
	name: "commit",
	category: "Bots",
	usage: 'commit [id do bot]',
	aliases: ['c'],
	description: "Veja meus comandos.",
	run: async (client, message, args) => {
		if (message.guild.channels.cache.find(f => f.name === `${message.author.id}-addbot`)) return message.reply("you alredy have a channel to add your bot in the host! " + message.guild.channels.cache.find(f => f.name === `${message.author.id}-addbot`))
		let id = args[0]
		if (!id) return message.reply('you need to give me a id from your bot!') //783050574836138046-681532724045283429
		if (fs.existsSync(`Bots/${id}-${message.author.id}`)) {
      let online = quickdb.get(id)
      if(online){
			  pm2.stop(id)
        quickdb.set("BotsOnline",quickdb.get("BotsOnline") - 1 )
        quickdb.set(id,false)
      }
      

			const dir = `Bots/${id}-${message.author.id}`;


			fs.rmdir(dir, {
				recursive: true
			}, (err) => {
				if (err) {
					throw err;
				}
			});
			quickdb.set(`${id}`, false)
			let guild = message.guild
			let TicketCategory = guild.channels.cache.get('930910078599585863')
			let roi = await guild.channels.create(`${message.author.id}-addbot`, {
				type: 'text',
				parent: TicketCategory.id,
				permissionOverwrites: [{
						allow: 'VIEW_CHANNEL',
						id: message.author.id
					},
					{
						deny: 'VIEW_CHANNEL',
						id: guild.id
					}
				]
			})
			roi.reply(`send me the .zip file from your bot`)
			let filter = m => m.author.id === message.author.id;
			let collector1 = roi.createMessageCollector(filter, {
				time: 600000
			})
			let link1 = ""
			let arquivo = ""
			collector1.on("collect", m => {
				var Attachment = (m.attachments)
				if (Attachment.array()[0]) {
					let link = new URL.URL(Attachment.array()[0].url);
					let test = link.pathname.split("/").reverse()[0]
					let nozip = test.replace(".zip", "")
					let a = test.replace(nozip, "")
					console.log(`${a}\n${nozip}\n${test}`)
					if (a === ".zip") {
						link1 = Attachment.array()[0].url
						collector1.stop()
					} else return m.reply('please give me a .zip file!')
				} else return m.reply('you need to send me a .zip file!')
			})
			collector1.on('end', () => {
				if (link1 === "") message.author.send('you take too long to answer!')
				if (link1 === "") return roi.delete()
				let collector2 = roi.createMessageCollector(filter, {
					time: 600000
				})
				roi.reply(`what file is your bot in? bot.js, index.js etc ...`)
				collector2.on('collect', m => {
					arquivo = m.content
					collector2.stop()
				})

				collector2.on('end', async () => {
					if (arquivo === "") message.author.send('you take too long to answer!')
					if (arquivo === "") return roi.delete()
					let emoji1 = "<:carregando:930514467454869585>" //caregando
					let emoji2 = "<:certo:930514576531947550>" //checkado
					let emoji3 = "<:errado:930514600057798686>" //deu erro
					let a = await roi.send(`
${emoji1} - checking .zip file...
${emoji1} - checking ${arquivo}...
${emoji1} - puting the bot in the host...
	`)
          ZipCode = Math.random() * (99999 - 00000) + 00000
					download(link1, `${ZipCode}${id}`)
					let link2 = new URL.URL(link1);
					let test1 = link2.pathname.split("/").reverse()[0]
					fs.mkdirSync(__dirname+'/Bots/' + `${id}-${message.author.id}`)

					unzip(`${id}-${message.author.id}`, `${ZipCode}${id}`)
					setTimeout(function() {
						a.edit(`
${emoji2} - successfully checked  the .zip file!
${emoji1} - checking ${arquivo}...
${emoji1} - puting the bot in the host...
`)
						setTimeout(function() {
							if (fs.existsSync(__dirname+"/Bots/" + id + "-" + message.author.id + "/" + arquivo)) {
								a.edit(`
${emoji2} - successfully checked the .zip file!
${emoji2} - successfully checked ${arquivo}!
${emoji1} - puting the bot in the host!
`)
								setTimeout(function() {
									a.edit(`
${emoji2} - successfully checked the .zip file!
${emoji2} - successfully checked ${arquivo}!
${emoji2} - bot successfully placed on the host!
`)
								}, 3000);
								setTimeout(function() {
									roi.delete()
									message.author.send('bot successfully placed on the host!')


									setTimeout(function() {
										if (message.member.roles.cache.has('815757201863081995')) {

											pm2.start({
												name: id,
												script: __dirname + "/Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
												max_memory_restart: ramruby //M = MB
											}, function(err, proc) {
                        quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
                        quickdb.set(id,true)
												console.log('ligado')
												if (err) console.error(err)
											});
										} else {
											if (message.member.roles.cache.has('815757398123872286')) {
												pm2.start({
													name: id,
													script: __dirname +"/Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
													max_memory_restart: ramdiamond //M = MB
												}, function(err, proc) {
                          quickdb.set(id,true)
                          quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
													console.log('ligado')
													if (err) console.error(err)
												});
											} else {
												pm2.start({
													name: id,
													script: __dirname + "/Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
													max_memory_restart: ramgratis //M = MB
												}, function(err, proc) {
                          quickdb.set(id,true)
                          quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
													console.log('ligado')
													if (err) console.error(err)
												});
											}
										}
									}, 6000);

									quickdb.set(`${id}_arquivo`, arquivo)
									quickdb.set(`${id}_owner`, message.author.id)
									quickdb.set(`${id}`, true)
									let channel = message.guild.channels.cache.get('815756314071400458')
									let embed2 = new Discord.MessageEmbed()
										.setColor(random)
										.setDescription(`bot successfully updated! \n bot: <@${id}>`)
									channel.send(message.author, embed2)
								}, 10000);
							} else {
								a.edit(`
${emoji2} - successfully checked the .zip file!
${emoji3} - there is no file called ${arquivo} in the bot's .zip!
${emoji3} - error no file named ${arquivo}!
`)
								const dir = `${__dirname}/Bots/${id}-${message.author.id}`;


								fs.rmdir(dir, {
									recursive: true
								}, (err) => {
									if (err) {
										throw err;
									}
								});
								setTimeout(function() {
									roi.delete()
									message.author.send('please check your .zip file and see if it really has a ' + arquivo + '!')
								}, 10000);
							}
						}, 3000);
					}, 3000);
				})
			})

		} else return message.reply('porfavor me te um id dos seus bots valido!')
	}
}