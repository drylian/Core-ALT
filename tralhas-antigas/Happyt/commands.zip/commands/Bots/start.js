const pm2 = require('pm2')
const Discord = require('discord.js');
const fs = require('fs');
const quickdb = require('quick.db');
let random = 'RANDOM'


let ramfree = "100M"
let rambasic = "300M"
let rammedium = "500M"
let ramexpert = "1500M"

module.exports = {
	name: "start",
	category: "Bots",
	usage: 'iniciar [id do bot]',
	aliases: ['iniciar'],
	description: "Veja meus comandos.",
	run: async (client, message, args) => {
		let id = args[0]
		if (!id) return message.reply('you need to send me the id from your bot!')
		if (fs.existsSync(`Bots/${id}-${message.author.id}`)) {
			let arquivo = quickdb.get(`${id}_arquivo`)
			if (message.member.roles.cache.has('929558939476049980')) {

				pm2.start({
					name: id,
					script: "../../Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
					max_memory_restart: ramexpert //M = MB
				}, function(err, proc) {
					console.log('ligado')
					if (err) console.error(err)
				});
			} else {
				if (message.member.roles.cache.has('815757398123872286')) {
					pm2.start({
						name: id,
						script: "../../Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
						max_memory_restart: rammedium //M = MB
					}, function(err, proc) {
						console.log('ligado')
						if (err) console.error(err)
					});
				} else {
					pm2.start({
						name: id,
						script: "../../Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
						max_memory_restart: ramfree //M = MB
					}, function(err, proc) {
						console.log('ligado')
						if (err) console.error(err)
					});
				}
			}
			let channel = message.guild.channels.cache.get('1049875345576296579')
			let embed2 = new Discord.MessageEmbed()
				.setColor(random)
				.setDescription(`bot started sucesfully! \n bot: <@${id}>`)
			channel.send(message.author, embed2)
			message.reply('bot started sucesfully!')
			quickdb.set(`${id}`, true)
      quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
		} else return message.reply('please give me a valid bot id!')
	}
}