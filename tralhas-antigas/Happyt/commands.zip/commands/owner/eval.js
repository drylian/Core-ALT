const Discord = require('discord.js');
const db = require('quick.db')
const pm2 = require('pm2')
const fs = require('fs')

let ramfree = "100M"
let rambasic = "300M"
let rammedium = "500M"
let ramexpert = "1500M" 

module.exports = {
    name: "eval",
    category: "owner",
    usage: 'eval',
    aliases: ['e'],
    description: "execute comandos.",
    run: async (client, message, args) => {
			let owners = ['681532724045283429','931228788551995402','938451792604307526']
			if(owners.includes(message.author.id)){
				let findOwner = function(id){
					return db.get(`${id}_owner`) !== null ? db.get(`${id}_owner`) : "Não pude encontrar o Dono do Bot :("
				}
				let findArquivo = function(id){
					return db.get(`${id}_arquivo`) !== null ? db.get(`${id}_arquivo`) : "Não pude encontrar os arquivos do Bot :("
				}
				let run = function(id,arquivo,ram){
					pm2.start({
						name: id,
						script: "../../Bots/" + `${id}-${findOwner(id)}` + "/" + arquivo,
						max_memory_restart: ram //M = MB
						}, function(err, proc) {
							quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
							console.log('ligado')
							if (err) console.error(err)
						});
				}
				let stopBot = function(id){
					let online = db.get(id)
					if(online){
						pm2.stop(id)
						db.set(id,false)
						db.set("BotsOnline",db.get("BotsOnline") - 1)
					}else return "Esse Bot já esta Offline!"
				}
        let runNode = function(id){
					const quickdb = require('quick.db')
const { spawn, spawnSync } = require("child_process"),
fs = require('fs');

console.log("Preparando o Bot...")
setTimeout(() => {
fs.readdirSync('Bots/').forEach(m => {
		let b = m
		client.guilds.cache.get('922227893298401372').members.cache.filter(e => !e.user.bot).forEach(e => {
			let a = b.replace(e.id, "")
			b = a
		})
		let ea = b.replace("-", "")
		b = ea
		let id = b
		let guild = client.guilds.cache.get('922227893298401372')
		if (guild.members.cache.get(id)) {
			client.guilds.cache.get('922227893298401372').members.cache.filter(m => m.user.bot).forEach(m => {
				if (m.user.bot) {
					if (quickdb.get(m.id)) {
						let ownerid = quickdb.get(m.id + '_owner')
						let owner = client.guilds.cache.get('922227893298401372').members.cache.get(ownerid)

setTimeout(() => {
  console.log("Iniciando o bot...")
  const { exec } = require('child_process');

  exec('cd /home/runner/elcorcloud/Bots/' + m.id + '-' + quickdb.get(m.id + '_owner') + '&& npm install && node index.js')
}, 5000)
          }
        }
      })
    }
})
}, 5000)
				}
				let runBot = function(id){
					let online = db.get(id)
					if(!online){
						let arquivo = findArquivo(id)
						db.set(id,true)
						let ownerId = findOwner(id)
						let owner = message.guild.members.cache.find(ownerId)
						if(owner !== null){
							if (owner.roles.cache.has('929558939476049980')) { 
								run(id,ramexpert,arquivo)
							} else if (owner.roles.cache.has('929558833460822108')) {
								run(id,rammedium,arquivo)
							} else {
								run(id,ramfree,arquivo)
							}
						}
					}else return "Este Bot já esta Online!"
				}
				let deleteBot = function(id){
					let dir = "Bots/"+`${id}-${findOwner(id)}`
					console.log(findOwner(id))
					if(fs.existsSync(dir)){
						let online = db.get(id)
						if(online){
							stopBot(id)
						}
						fs.rmdir(dir, {
							recursive: true
						}, (err) => {
							if (err) {
								throw err;
							}
						});
						db.set("BotsOnHost",db.get("BotsOnHost") - 1)
						return "Deletado!"
					} else return "Erro na hora de deletar o bot!"
				}
				const code = args.join(" ")
				try {
		      let resultado = await eval(code)
		      var tipo = typeof(resultado)
					let embed = new Discord.MessageEmbed()
		        .addField('Código', '```js\n' + `${code}` + '\n```', false)
		        .addField('Resultado', '```js\n' + `${resultado}` + '\n```', false)
		        .addField('Tipo', '```js\n' + `${tipo}` + '\n```', false)
		        .setColor("#383838")
		    	message.channel.send(embed)
		    } catch(err) {
		      let embed = new Discord.MessageEmbed()
		        .addField('Código', '```js\n' + `${code}` + '\n```', false)
		        .addField('Erro', '```js\n' + `${err}` + '\n```', false)
		        .setColor("#383838")
		      message.channel.send(embed)
		   }
			}else {console.log("ha")}
   }
}