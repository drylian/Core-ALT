const Discord = require('discord.js');
const db = require('quick.db')
module.exports = {
    name: "test",
    category: "Test",
    usage: 'test',
    aliases: ['t'],
    description: "Veja meus comandos.",
    run: async (client, message) => {
		message.channel.send({content:`Tem ${db.get("BotsOnline")}/${db.get("BotsOnHost") < 0 ? 0 :  db.get("BotsOnHost")} Bots Online!`})
   }
}