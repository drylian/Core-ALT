const Discord = require('discord.js');

module.exports = {
    name: "help",
    category: "Info",
    usage: 'help',
    aliases: ['ajuda'],
    description: "Veja meus comandos.",
    run: async (client, message) => {
        let embed = new Discord.MessageEmbed()
		.setTitle('Commands')
		.setColor('BLUE')
        .setDescription("here is all of my commands!")
		.addField('key','command to use a key!')
		.addField('run','command to run your bot!')
        .addField('stop','command to stop your bot!')
		.addField('commit','command to update your bot!')
		.addField('up','command for adding your bot!')
		.addField('remove/delete','command for removing/deleting your bot!')
		message.channel.send(embed)
   }
}