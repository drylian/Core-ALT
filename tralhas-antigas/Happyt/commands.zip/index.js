const { Client, Intents, Collection } = require('discord.js');
const { readdirSync } = require('fs');
const { join } = require('path');

const client = new Client({ intents: 32767 });

let db = require("quick.db")
db.set("BotsOnline", 0)
db.set("BotsOnHost", -0)

client.commands = new Collection();
client.aliases = new Collection();

require('./website/index.js')

client.login('MTA1MjA0OTQ3MTUwMjAyNDcwNA.GSdApr.ZtxVqF_aT8SDIOQg7uHUiSXj_EcaQFSnqlSFi0');

const eventFiles = readdirSync(join(__dirname, "events")).filter((file) => file.endsWith(".js"));
    
  for (const file of eventFiles) { 
    const event = require(join(__dirname, "events", `${file}`)); 
    let eventName = file.split(".")[0]; 
    client.on(eventName, (...args) => event.run(client, ...args))
  }

readdirSync(join(__dirname, "commands")).forEach(dir => { 
    const commands = readdirSync(`./commands/${dir}/`).filter(file => file.endsWith(".js"));

    
    for (let file of commands) { 
        let pull = require(`./commands/${dir}/${file}`);

        if (pull.name) {
            client.commands.set(pull.name, pull);
            console.log(file, '✅ -> Carregado com sucesso!');
        } else {
            console.log(file, '❌ -> Ops, houve um erro ao carregar!'); 
            continue; 
        }
        if (pull.aliases && Array.isArray(pull.aliases)) pull.aliases.forEach(alias => client.aliases.set(alias, pull.name));
    }
});