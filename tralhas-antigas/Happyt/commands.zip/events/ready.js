const fs = require('fs');
const pm2 = require('pm2');
const quickdb = require('quick.db')
let role1 = '929558738493395094',
role2 = '929558833460822108',
role3 = '929558939476049980',
guildid = '1049163000424185987'
ramruby = '512M',
ramdiamond = '300M',
ramgratis = '128M';

module.exports.run = (client) => {

	try {
		client.user.setStatus("dnd")
	} catch (err) {
		console.log(err)
	}
	console.log(`[BOT] - Iniciado com sucesso!`)

	fs.readdirSync('Bots/').forEach(m => {
		let b = m
		client.guilds.cache.get(guildid).members.cache.filter(e => !e.user.bot).forEach(e => {
			let a = b.replace(e.id, "")
			b = a
		})
		let ea = b.replace("-", "")
		b = ea
		let id = b
		let guild = client.guilds.cache.get(guildid)
		if (guild.members.cache.get(id)) {
			client.guilds.cache.get(guildid).members.cache.filter(m => m.user.bot).forEach(m => {
				if (m.user.bot) {
          quickdb.set("BotsOnHost",quickdb.get("BotsOnHost")+1)
					if (quickdb.get(`${m.id}`)) {
						let ownerid = quickdb.get(`${m.id}_owner`)
						let owner = client.guilds.cache.get(guildid).members.cache.get(ownerid)
						if (owner.roles.cache.has(role3)) {
							pm2.start({
								name: m.id,
								script: "Bots/" + `${m.id}-${quickdb.get(`${m.id}_owner`)}` + "/index.js",
								max_memory_restart: ramruby //M = MB
							}, function(err, proc) {
								if (err) return console.error(err)
                quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
								console.log('[HOST] - Ligado com sucesso o bot "' + m.user.tag + '"!')
							});
						} else {
							if (owner.roles.cache.has(role2)) {
								pm2.start({
									name: m.id,
									script: "Bots/" + `${m.id}-${quickdb.get(`${m.id}_owner`)}` + "/index.js",
									max_memory_restart: ramdiamond //M = MB
								}, function(err, proc) {
									if (err) return console.error(err)
                  quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
									console.log('[HOST] - Ligado com sucesso o bot "' + m.user.tag + '"!')
								});
							} else {
								pm2.start({
									name: m.id,
									script: "Bots/" + `${m.id}-${quickdb.get(`${m.id}_owner`)}` + "/index.js",
									max_memory_restart: ramgratis //M = MB
								}, function(err, proc) {
									if (err) return console.error(err)
                  quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
									console.log('[HOST] - Ligado com sucesso o bot "' + m.user.tag + '"!')
								});
							}
						}
					}
				}
			})
		} /*else {
			let a = quickdb.get(`${id}_arquivo`)
      quickdb.set("BotsOnHost",quickdb.get("BotsOnHost")+1)
			if (quickdb.get(`${id}`)) {
				let ownerid = quickdb.get(`${id}_owner`)
				let owner = client.guilds.cache.get(guildid).members.cache.get(ownerid)
				if (owner.roles.cache.has(role3)) {

					pm2.start({
						name: id,
						script: "Bots/" + `${m.id}-${quickdb.get(`${m.id}_owner`)}` + "/index.js",
						max_memory_restart: ramruby //M = MB
					}, function(err, proc) {
						if (err) return console.error(err)
            BotsOnline = quickdb.get("BotsOnline") + 1
						console.log('[HOST] - Ligado com sucesso o bot ' + id + "!")
					});
				} else {
					if (owner.roles.cache.has(role2)) {
						pm2.start({
							name: id,
							script: "Bots/" + `${m.id}-${quickdb.get(`${m.id}_owner`)}` + "/index.js",
							max_memory_restart: ramdiamond //M = MB
						}, function(err, proc) {
							if (err) return console.error(err)
              BotsOnline = quickdb.get("BotsOnline") + 1
							console.log('[HOST] - Ligado com sucesso o bot ' + id + "!")
						});
					} else {
						pm2.start({
							name: m.id,
							script: "Bots/" + `${m.id}-${quickdb.get(`${m.id}_owner`)}` + "/index.js",
							max_memory_restart: ramgratis //M = MB
						}, function(err, proc) {
							if (err) return console.error(err)
              BotsOnline = quickdb.get("BotsOnline") + 1
							console.log('[HOST] - Ligado com sucesso o bot ' + id + "!")
						});
					}
				}
			}
		}*/
	})
}