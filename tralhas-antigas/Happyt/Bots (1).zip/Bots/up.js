let pm2 = require('pm2')
const Discord = require('discord.js')
var https = require('https');
var fs = require('fs');
let URL = require('url')
let quickdb = require('quick.db')
let random = 'RANDOM'
let ZipCode = 00000
// fs.mkdirSync('./bots/pasta') 

var download = async function(url, idbot) {
  if (fs.existsSync('botszip/' + `ot-${idbot}.zip`)) {
    ZipCode = Math.random() * (99999 - 00000) + 00000
download(url, idbot)
  }else{
  const file = fs.createWriteStream(`botszip/bot-${idbot}.zip`);
  https.get(url, res => {
  res.pipe(file)
  });
  }
}


let unzip = async function(name, idbot) {
setTimeout(function() {
const decompress = require("decompress");
//Ping
decompress(`botszip/bot-${idbot}.zip`, "Bots/" + name).then((files, err) => {
console.log(files);
if (err) console.error(err)
});
setTimeout(function() {
fs.unlinkSync(`botszip/bot-${idbot}.zip`)
}, 3000);
}, 3000);
}
let ramfree = "100M"
let rambasic = "300M"
let rammedium = "500M"
let ramexpert = "1500M" 

module.exports = {
name: "up",
category: "Bots",
usage: 'up',
aliases: [],
description: "Mande seu bot para a nossa host.",
run: async (client, message, args) => {
if (message.guild.channels.cache.find(f => f.name === `${message.author.id}-addbot`)) return message.reply("você já tem um canal para adicionar seu bot." + message.guild.channels.cache.find(f => f.name === `${message.author.id}-addbot`))
if (message.member.roles.cache.has('1051529545053900942')) { 

} else if (message.member.roles.cache.has('929558833460822108')) {
if (quickdb.get(`${message.author.id}_bots`) === 3) return message.reply("you alredy have the max of bots(3)!")
} else {
if (quickdb.get(`${message.author.id}_bots`) === 1) return message.reply("you alredy have the max of bots(1)!")
}
let guild = message.guild
let TicketCategory = guild.channels.cache.get('1050092920390303846')
let roi = await guild.channels.create(`${message.author.id}-addbot`, {
type: 'text',
parent: TicketCategory.id,
permissionOverwrites: [{
allow: 'VIEW_CHANNEL',
id: message.author.id
},
{
deny: 'VIEW_CHANNEL',
id: guild.id
}
]
})
    message.reply(`Vá para o canal <#${roi.id}>`)
    roi.send("Envie o arquivo .ZIP do seu bot.")
let filter = m => m.author.id === message.author.id;
let collector1 = roi.createMessageCollector(filter, {
time: 600000
})
let link1 = ""
let arquivo = ""
let id = ""
collector1.on("collect", m => {
var Attachment = m.attachments;
if (m.attachments.array()[0]) {
let link = new URL.URL(Attachment.array()[0].url);
let test = link.pathname.split("/").reverse()[0]
let nozip = test.replace(".zip", "")
let a = test.replace(nozip, "")
console.log(`${a}\n${nozip}\n${test}`)
if (a === ".zip") {
link1 = Attachment.array()[0].url
collector1.stop()
} else return m.reply('você precisa me enviar um arquivo .zip')
} else return m.reply('você precisa me enviar um arquivo .zip')
})
collector1.on('end', () => {
if (link1 === "") message.author.send('Você demorou muito para responder! ')
if (link1 === "") return roi.delete() 

let collector2 = roi.createMessageCollector(filter, {
time: 600000
})
roi.send(`Qual arquivo principal do Bot? index.js, bot.js etc`)
collector2.on('collect', m => {
arquivo = m.content
let a = arquivo.replace('.js', '')
let b = arquivo.replace(a, "")
if (b !== ".js") return m.reply("não aceitamos arquivos que não seja .js(JavaScript)!")
collector2.stop()
})
collector2.on('end', () => {
if (arquivo === "") message.author.send('Você demorou pra responder.')
if (arquivo === "") return roi.delete()
let collector3 = roi.createMessageCollector(filter, {
time: 600000
})
roi.send(`Qual o ID do seu Bot?`)
collector3.on("collect", m => {
id = m.content
collector3.stop()
})
collector3.on('end', async () => {
if (id === "") message.author.send('Você demorou pra responder!')
if (id === "") return roi.delete()
let emoji1 = "<a:carregando:930514467454869585>" //caregando
let emoji2 = "<:certo:930514576531947550>" //checkado
let emoji3 = "<:errado:930514600057798686>" //deu erro
if (fs.existsSync('Bots/' + id + '-' + message.author.id)) {
roi.send('this bot is alredy in the host! please use !update ' + id + ' !')
setTimeout(function() {
roi.delete()
}, 10000)
} else {
let a = await roi.send(`${emoji1} - analisando .zip  ...\n${emoji1} - analisando ${arquivo}...\n${emoji1} - adicionando Bot na host...
        `)
            ZipCode = Math.random() * (99999 - 00000) + 00000
download(link1, `${ZipCode}${id}`)
let link2 = new URL.URL(link1);
let test1 = link2.pathname.split("/").reverse()[0]
fs.mkdirSync('Bots/' + `${id}-${message.author.id}`) 

unzip(`${id}-${message.author.id}`, `${ZipCode}${id}`)
//fs.existsSync("Bots/" + id + "-" + message.author.id + "/" + 'package.json')
setTimeout(function() {
a.edit(`${emoji2} - analisado .zip com sucesso.\n${emoji1} - analisando ${arquivo}...\n${emoji1} - adicionando Bot na host...`)
setTimeout(function() {
if (fs.existsSync("Bots/" + id + "-" + message.author.id + "/" + arquivo)) {
a.edit(`${emoji2} - analisado .zip com sucesso.\n${emoji2} - analisado ${arquivo} com sucesso.\n${emoji1} - adicionando Bot na host...`)
const data = `const { Client, Intents, Collection } = require('discord.js');

const client = new Client({ intents: 32767 });
client.login('OTUyMzU2MDY1MjA5NjIyNjI5.Yi00sw.1a3TKEkESnYQSTnBs5m8Y5E8VBI').then(() => {console.log('Oi')});

const quickdb = require('quick.db')
const { spawn, spawnSync } = require("child_process"),
shell = require('shelljs'),
fs = require('fs');

console.log("Preparando o Bot...")
setTimeout(() => {
fs.readdirSync('Bots/').forEach(m => {
		let b = m
		client.guilds.cache.get('922227893298401372').members.cache.filter(e => !e.user.bot).forEach(e => {
			let a = b.replace(e.id, "")
			b = a
		})
		let ea = b.replace("-", "")
		b = ea
		let id = b
		let guild = client.guilds.cache.get('922227893298401372')
		if (guild.members.cache.get(id)) {
			client.guilds.cache.get('922227893298401372').members.cache.filter(m => m.user.bot).forEach(m => {
				if (m.user.bot) {
					if (quickdb.get(m.id)) {
						let ownerid = quickdb.get(m.id + '_owner')
						let owner = client.guilds.cache.get('922227893298401372').members.cache.get(ownerid)

setTimeout(() => {
  console.log("Iniciando o bot...")
  const { exec } = require('child_process');

  exec('cd /home/runner/elcorcloud/Bots/' + m.id + '-' + quickdb.get(m.id + '_owner') && npm install && node index.js)
}, 5000)
          }
        }
      })
    }
})
}, 5000)`;
/*fs.writeFileSync("Bots/" + id + "-" + message.author.id + '/index.js', data, (err) => {
    if (err) throw err;
  console.log('O arquivo foi criado!');
});*/
setTimeout(function() {
a.edit(`${emoji2} - analisado .zip com sucesso.\n${emoji2} - analisado ${arquivo} com sucesso.\n${emoji2} - adicionado Bot na host com sucesso.`)
}, 3000);
setTimeout(function() {
roi.delete()


setTimeout(function() {
if (message.member.roles.cache.has('929558939476049980')) { 

pm2.start({
name: id,
script: "../../Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
max_memory_restart: ramexpert //M = MB
}, function(err, proc) {
                          quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
                          quickdb.set("BotsOnHost",quickdb.get("BotsOnHost") + 1)
console.log('ligado')
if (err) console.error(err)
});
} else {
if (message.member.roles.cache.has('929558833460822108')) {
pm2.start({
name: id,
script: "../../Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
max_memory_restart: rammedium //M = MB
}, function(err, proc) {
                            quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
                            quickdb.set("BotsOnHost",quickdb.get("BotsOnHost")+1)
console.log('ligado')
if (err) console.error(err)
});
} else {
pm2.start({
name: id,
script: "../../Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
max_memory_restart: ramfree //M = MB
}, function(err, proc) {
                            quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
                            quickdb.set("BotsOnHost",quickdb.get("BotsOnHost")+1)
console.log('ligado')
if (err) {
  pm2.start({
name: id,
script: "../../Bots/" + `${id}-${message.author.id}` + "/" + arquivo,
max_memory_restart: ramfree //M = MB
})
}
});
}
}
let channel = message.guild.channels.cache.get('1049875345576296579')
let embed = new Discord.MessageEmbed()
.setColor(random)
.setDescription(`bot successfully placed on the host! \n bot: <@${id}>`)
.setFooter(`id: ${id}`)
channel.send({
content: message.author,
embeds: [embed]
})
let embed2 = new Discord.MessageEmbed()
.setColor(random)
.setDescription(`bot started successfully \n bot: <@${id}>`)
channel.send(message.author, embed2)
}, 12000); 

quickdb.set(`${id}_arquivo`, arquivo)
quickdb.set(`${id}_owner`, message.author.id)
quickdb.set(`${id}`, true)
quickdb.add(`${message.author.id}_bots`, 1)
}, 10000);
} else {
a.edit(`
    ${emoji2} - analisado .ZIP com sucesso.
    ${emoji3} - não encontrei um ${arquivo} em seu zip
    ${emoji3} - erro no arquivo ${arquivo}!
    `)
const dir = `Bots/${id}-${message.author.id}`;


fs.rmdir(dir, {
recursive: true
}, (err) => {
if (err) {
throw err;
}
});
setTimeout(function() {
roi.delete()
message.author.send({
content: 'please check your .zip file and see if it really has a ' + arquivo + '!'
})
}, 10000);
}
}, 3000);
}, 3000); 

}
})
})
})
}
}