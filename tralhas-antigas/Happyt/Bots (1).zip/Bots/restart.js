const pm2 = require('pm2')
const Discord = require('discord.js');
const fs = require('fs');
const quickdb = require('quick.db');

let ramfree = "100M"
let rambasic = "300M"
let rammedium = "500M"
let ramexpert = "1500M"
let random = 'RANDOM'

module.exports = {
	name: "restart",
	category: "Host",
	usage: 'restart',
	aliases: ['r'],
	description: "Veja meus comandos.",
	run: async (client, message, args) => {
		let id = args[0]
		if (!id) return message.reply('you need to send me the id from your bot!')
		if (fs.existsSync(`Bots/${id}-${message.author.id}`)) {
			let arquivo = quickdb.get(`${id}_arquivo`)
      let online = quickdb.get(id)
      if(online){
        quickdb.set("BotsOnline",quickdb.get("BotsOnline") - 1 )
			  pm2.stop(id)
      } 
			setTimeout(function() {
				if (message.member.roles.cache.has('815757201863081995')) {

					pm2.start({
						name: id,
						script: "../../Bots/" + `${id}-${message.author.id}` + "/" + 'elcorcloud.nodeconfig.js',
						max_memory_restart: ramexpert //M = MB
					}, function(err, proc) {
            quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
						console.log('ligado')
						if (err) console.error(err)
					});
				} else {
					if (message.member.roles.cache.has('815757398123872286')) {
						pm2.start({
							name: id,
							script: "../../Bots/" + `${id}-${message.author.id}` + "/" + 'elcorcloud.nodeconfig.js',
							max_memory_restart: rammedium //M = MB
						}, function(err, proc) {
              quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
							console.log('ligado')
							if (err) console.error(err)
						});
					} else {
						pm2.start({
							name: id,
							script: "../../Bots/" + `${id}-${message.author.id}/${arquivo}`,
							max_memory_restart: ramfree //M = MB
						}, function(err, proc) {
              quickdb.set("BotsOnline",quickdb.get("BotsOnline") + 1 )
							console.log('ligado')
							if (err) {
                pm2.start({
							name: id,
							script: "../../Bots/" + `${id}-${message.author.id}/${arquivo}`,
							max_memory_restart: ramfree //M = MB
						})
              }
              
						});
					}
				}
				let channel = message.guild.channels.cache.get('1049875345576296579')
				let embed2 = new Discord.MessageEmbed()
					.setColor("random")
					.setDescription(`bot successfully restarted! \n bot: <@${id}>`)
				channel.send(embed2)
				message.reply('bot successfully restarted!')
			}, 3000);
		} else return message.reply('please give me a valid bot id!')
	}
}