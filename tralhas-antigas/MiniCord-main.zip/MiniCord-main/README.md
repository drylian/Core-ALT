# MiniCord

## Details 😉
- MongoDB | Verison `6.1.1`
- Express | Verison `Last Verison`
- And More
- Main File | `index.js`

- ### Developer Discord Profile 😊
![Discord](https://discord.c99.nl/widget/theme-1/919719379439071242.png)

---

- ### High Project ⚒ : <img src="https://cdn.discordapp.com/emojis/945392594572152903.webp?size=80&quality=lossless" width="20" height="25"> [@Noura.](https://discord.gg/m56w5Tez3a) | <img src="https://cdn.discordapp.com/attachments/960194274769645619/1024954169137823764/logo1.png" width="20" height="25"> [@Gold Bot.](https://discord.gg/h22fM858mG)
- You Found Bug Or Issues? Add Comment in Issuse Area
---
- ![Only.Ahmed GitHub stats](https://github-readme-stats.vercel.app/api?username=Ahmed1Dev&show_icons=true&theme=radical)
