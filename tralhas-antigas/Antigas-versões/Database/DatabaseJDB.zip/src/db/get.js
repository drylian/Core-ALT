const { saveDB, loadDB } = require('../functions/controller');
const { log } = require('../functions/logmanager');

function get(field, id = null) {
    const database = loadDB();
    
    if (!database[field]) {
        log(`Field '${field}' não existe.`);
        return null;
    } else {
        if (id) {
            if (!database[field][id]) {
                log(`Field '${field}.${id}' não existe.`);
                return null;
            } else {
                if (database[field][id].hasOwnProperty('JDB_metadata')) {
                    delete database[field][id].JDB_metadata;
                }
                log(`Field '${field}.${id}' foi desencriptado.`);
                return database[field][id];
            }
        } else {
            if (database[field].hasOwnProperty('JDB_metadata')) {
                delete database[field].JDB_metadata;
            }
            log(`Retornando todo o Field '${field}'.`);
            return database[field];
        }
    }
}

module.exports = { get };
