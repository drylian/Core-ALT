
module.exports = {
    name: "interactionCreate"
};

client.on('interactionCreate', async (interaction) => {

    }
)