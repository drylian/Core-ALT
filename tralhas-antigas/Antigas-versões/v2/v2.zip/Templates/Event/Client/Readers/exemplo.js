module.exports = {
    name: 'Alguma coisa',
    run: async (client) => {
    }
}