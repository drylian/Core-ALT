const colors = require('colors');
const nodemon = require('nodemon');
// Função para iniciar o servidor em modo de desenvolvimento

module.exports = { DevServer };
