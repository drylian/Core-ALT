<h1 align="center">
    <p>Discord BOT Dashboard - V2</p>
</h1>
You can access the GitHub repository for Discord BOT Dashboard <a href="https://github.com/LachlanDev/Discord-BOT-Dashboard-V2" target="_blank">here.</a>

## 📚 About
Discord BOT Dashboard V2 is the successor of <a href="https://github.com/LachlanDev/Discord-BOT-Dashboard" target="_blank">Discord BOT Dashboard</a>, Discord BOT Dashboard V2 is made to make **Discord BOT Development** easy, designed to create applications without having to write a single line of code while using a user friendly Web-Dashboard!
<br><br>
This Documentation page will hopefully help you install and get Discord BOT Dashboard running, if you run into any errors or need any extra help feel free to use any of the contact methods below!

## 📞 Contact
Created by LachlanDev#8014

* [Website](https://lachlan-dev.com)
* [Twitter](https://twitter.com/LachlanDev)
* [Instagram](https://www.instagram.com/LachlanDev/)
* [Discord Server](https://discord.com/invite/w7B5nKB)
