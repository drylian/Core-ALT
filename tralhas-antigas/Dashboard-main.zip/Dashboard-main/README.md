# Installation

To start, clone this github repository to your local machine:

```
git clone https://github.com/Guardians-Stuff/Dashboard
```

If you don't have git installed on your local machine, you can install it like so:

```
git --version
```

After you have done that enter the directory aka the code you cloned and do

```
npm install
```

