// PLEASE FOLLOW THIS FORMAT TO AVOID BREAKING THE PAGE
/*
[Date]: {
  [Change Category]: [Change],
  [Change Category]: [Change 1, Change 2]
}
*/

export const changes = {
    '18/02/2023': {
        'Website Homepage': [
            'Website homepage has been implemented.',
            'Basic layout provided in a PR by @neeoll on Github'
        ]
    }
};