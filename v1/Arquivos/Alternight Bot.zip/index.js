const { Client, Intents, Collection } = require('discord.js');
const { readdirSync } = require('fs');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const { prefix, token, guildId, clientId } = require('./config.json');

const client = new Client({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES],
});

client.commands = new Collection();
const commandFiles = readdirSync('./Comandos').filter((file) => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(`./Comandos/${file}`);
  client.commands.set(command.data.name, command);
}

const rest = new REST({ version: '9' }).setToken(token);

(async () => {
  try {
    await rest.put(
        Routes.applicationGuildCommands(clientId, guildId),
        { body: client.commands.map((command) => command.data.toJSON()) },
      );      

    console.log('Comandos de barra registrados com êxito!');
  } catch (error) {
    console.error(error);
  }
})();

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isCommand()) return;

  const { commandName } = interaction;
  const command = client.commands.get(commandName);

  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(error);
    await interaction.reply({ content: 'Ocorreu um erro ao executar este comando!', ephemeral: true });
  }
});

client.on('ready', () => {
  console.log(`Logado como ${client.user.tag}!`);
});

client.login(token);
