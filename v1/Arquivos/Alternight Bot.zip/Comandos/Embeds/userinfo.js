const { MessageEmbed } = require('discord.js');

module.exports = (member) => {
    const user = member.user;
    const embed = new MessageEmbed()
        .setTitle('Informações do usuário')
        .addFields(
            { name: 'Nome', value: user.username },
            { name: 'ID', value: user.id },
            { name: 'Entrou no servidor em', value: member.joinedAt.toDateString() },
            { name: 'Conta criada em', value: user.createdAt.toDateString() },
        )
        .setColor('#0099ff')
        .setThumbnail(user.avatarURL({ dynamic: true }))
        .setTimestamp();


    return embed;
};
