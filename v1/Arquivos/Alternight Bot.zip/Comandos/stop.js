const { SlashCommandBuilder } = require('@discordjs/builders');
const { getVoiceConnection } = require('@discordjs/voice');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stop')
    .setDescription('Para de tocar a música e sai do canal de voz'),
  async execute(interaction) {
    const connection = getVoiceConnection(interaction.guildId);
    if (connection) {
      connection.destroy();
      await interaction.reply({ content: 'A música foi parada e o bot saiu do canal de voz.', ephemeral: true });
    } else {
      await interaction.reply({ content: 'O bot não está tocando nenhuma música!', ephemeral: true });
    }
  },
};
