const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const { createAudioPlayer, createAudioResource, entersState, AudioPlayerStatus, VoiceConnectionStatus, joinVoiceChannel } = require('@discordjs/voice');
const fs = require('fs');
const path = require('path');

const musicPath = path.join(__dirname, '..', 'Musicas');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Executa uma música local aleatória'),
  async execute(interaction) {
    const player = createAudioPlayer();
    const connection = await joinVoiceChannel({
      channelId: interaction.member.voice.channel.id,
      guildId: interaction.guild.id,
      adapterCreator: interaction.guild.voiceAdapterCreator,
    });
    
    try {
      let filenames = fs.readdirSync(musicPath).filter(file => file.endsWith('.mp3'));
      if (filenames.length === 0) {
        return await interaction.reply({ content: 'Nenhuma música encontrada!', ephemeral: true });
      }
      
      let currentSongIndex = 0;
      let timeout = null;
      
      const playSong = async () => {
        const songPath = path.join(musicPath, filenames[currentSongIndex]);
        const resource = createAudioResource(songPath);
        player.play(resource);
        
        const embed = new MessageEmbed()
          .setColor('#00ff00')
          .setTitle('Tocando agora:')
          .setDescription(`**${filenames[currentSongIndex]}**`)
          .setTimestamp();
        await interaction.reply({ embeds: [embed] });
        
        await entersState(player, AudioPlayerStatus.Idle, 5_000);
        currentSongIndex = (currentSongIndex + 1) % filenames.length;
        if (timeout) {
          clearTimeout(timeout);
        }
        timeout = setTimeout(() => {
          if (connection.state.status !== VoiceConnectionStatus.Destroyed && connection.state.subscription) {
            connection.destroy();
          }
        }, 5 * 60 * 1000); // 5 minutos
        await playSong();
      };
      
      await playSong();
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Ocorreu um erro ao reproduzir a música!', ephemeral: true });
    }
  },
};
